﻿BEGIN
  DECLARE @ProdId INT=2900,@Increment TINYINT=0
PRINT @ProdId
WHILE(@Increment<30)
BEGIN
SET @ProdId=@ProdId+2
SET @Increment=@Increment+1
PRINT @ProdId
END
END